<h3>
    {{ $pagina }} - {{ \App\Models\vista_pagina::show($pagina) }} visitas
</h3>
