<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lux/bootstrap.min.css" title="main">
    
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <style>
        .estilo {
            color: red;
            font-family: 'Courier New', Courier, monospace;
        }

    </style>
</head>

<body>
    <h1 class="estilo">Bienvenido usuario: <?php echo e(auth()->user()->usuario_dato->ud_nom); ?>

        <?php echo e(auth()->user()->usuario_dato->ud_app); ?></h1>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <div class="btn-group">
                            <button type="button" class="btn btn-secondary">Usuarios</button>
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="visually-hidden"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference">
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('usuario.registrar')); ?>">Registrar
                                            Nuevo Usuario</a></li>
                                    <li><a class="dropdown-item" href="<?php echo e(route('login.listar')); ?>">Listar login de
                                            los Usuarios</a></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('login.editarSession', auth()->user()->usuario_dato->id_login)); ?>">
                                        Cambiar login session</a></li>
                                <div class="dropdown-divider"></div>
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('usuario.editar', auth()->user()->usuario_dato->ud_id)); ?>">
                                        Modificar datos personales</a></li>
                                <li><a class="dropdown-item"
                                        href="<?php echo e(route('usuario.verPerfil', auth()->user()->usuario_dato->ud_id)); ?>">
                                        Ver Perfil</a></li>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('usuario.listar')); ?>">Listar todos los
                                            usuarios</a></li>
                                <?php endif; ?>
                                <div class="dropdown-divider"></div>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        Salir
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                        style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="btn-group">
                            <button type="button" class="btn btn-secondary">Proyectos Participacion</button>
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="visually-hidden"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                <a class="dropdown-item" href="<?php echo e(route('proyectos.listar')); ?>">Listar todos
                                    Proyectos</a>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('proyectos.crear')); ?>">Crear proyecto</a>
                                <?php endif; ?>
                                <div class="dropdown-divider"></div>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('participa.crear')); ?>">Registrar
                                        participacion</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('participa.listar')); ?>">Listar
                                    Participantes</a>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="btn-group">
                            <button type="button" class="btn btn-secondary">Reportes Estadisticas Hormigon</button>
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="visually-hidden"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                <a class="dropdown-item" href="<?php echo e(route('reporte.listar')); ?>">Listar Proyectos
                                    involucrados</a>
                                <a class="dropdown-item" href="<?php echo e(route('proyectos.estadistica')); ?>">generar
                                    estadistica</a>
                                <div class="dropdown-divider"></div>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('hormigon.crear')); ?>">Registrar Nuevo
                                        Hormigon</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('hormigon.listar')); ?>">Listar Hormigon</a>
                                <a class="dropdown-item" href="<?php echo e(route('reporte.acceso')); ?>">Estadistica por pagina</a>
                            </ul>
                        </div>
                    </li>

                    <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                        <li class="nav-item">
                            <div class="btn-group">
                                <button type="button" class="btn btn-secondary">Sucursal equipo almacenar</button>
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton3"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <span class="visually-hidden"></span>
                                </button>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference3">
                                    <a class="dropdown-item" href="<?php echo e(route('sucursales.crear')); ?>">Crear
                                        sucursal</a>
                                    <a class="dropdown-item" href="<?php echo e(route('sucursales.listar')); ?>">Listar
                                        sucursales</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('equipos.crear')); ?>">Crear
                                        equipos</a>
                                    <a class="dropdown-item" href="<?php echo e(route('equipos.listar')); ?>">Listar
                                        equipos </a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item" href="<?php echo e(route('almacena.crear')); ?>">Almacenar equipo en
                                        Sucursal</a>
                                    <a class="dropdown-item" href="<?php echo e(route('almacena.listar')); ?>">Ver equipo almacen
                                    </a>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
                    
                    <li class="nav-item">
                        <div class="btn-group">
                            <button type="button" class="btn btn-secondary">Empresa material costos</button>
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton3"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="visually-hidden"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference3">
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('empresas.crear')); ?>">Crear
                                        empresa</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('empresas.listar')); ?>">Listar
                                    empresa afiliadas</a>
                                <div class="dropdown-divider"></div>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('materiales.crear')); ?>">Crear
                                        material</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('materiales.listar')); ?>">Listar
                                    material guardado</a>
                                <div class="dropdown-divider"></div>
                                <?php if(auth()->user()->usuario_dato->id_tipo == 1 || auth()->user()->usuario_dato->id_tipo == 2): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('coopera.crear')); ?>">Crear material -
                                        empresa</a>
                                <?php endif; ?>
                                <a class="dropdown-item" href="<?php echo e(route('coopera.listar')); ?>">Listar material -
                                    empresa</a>
                            </ul>
                        </div>
                    </li>

                    <li class="nav-item">
                        <div class="btn-group">
                            <button type="button" class="btn btn-secondary">Temas</button>
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="visually-hidden"></span>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="cosmo">Modo dia</a>
                                </li>
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="cyborg">Modo noche</a>
                                </li>
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="sketchy">Niño</a></li>
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="lux">Adultos</a></li>
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="simplex">Jovenes</a>
                                </li>
                                <li><a class="dropdown-item change-style-menu-item" href="#" rel="sketchy">Niño</a></li>
                        </div>
                    </li>
                </ul>
                <form class="d-flex" action="<?php echo e(route('buscar')); ?>" method='GET'>
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search"
                        name="busqueda">
                    <button class="btn btn-outline-success" type="submit">Buscar</button>
                </form>
            </div>
        </div>
    </nav>

    <?php if(session('mensaje')): ?>
        <div class="card">
            <div class="card-body">
                <?php echo e(session('mensaje')); ?>

            </div>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js"></script>

    <script>
        // const hour = moment().hour();
        // if (hour >= 6) && (hour <= 18) {
        //     set_theme('cosmo');
        // } else {
        //     set_theme('cyborg');
        // }

        function supports_html5_storage() {
            try {
                return 'localStorage' in window && window['localStorage'] !== null;
            } catch (e) {
                return false;
            }
        }

        var supports_storage = supports_html5_storage();

        function set_theme(theme) {
            $('link[title="main"]').attr('href', theme);
            if (supports_storage) {
                localStorage.theme = theme;
            }
        }
        jQuery(function($) {
            $('body').on('click', '.change-style-menu-item', function() {
                var theme_name = $(this).attr('rel');
                var theme = "//cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/" + theme_name +
                    "/bootstrap.min.css";
                set_theme(theme);
            });
        });

        if (supports_storage) {
            var theme = localStorage.theme;
            if (theme) {
                set_theme(theme);
            }
        } else {
            /* Don't annoy user with options that don't persist */
            $('#theme-dropdown').hide();
        }
    </script>

</body>

</html>
<?php /**PATH D:\Tecnologia Web\proyecto2 web\ProyGupadis-3D\proygupadis-3d\resources\views/layauts/plantillaUser.blade.php ENDPATH**/ ?>