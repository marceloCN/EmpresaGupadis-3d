<h3>
    <?php echo e($pagina); ?> - <?php echo e(\App\Models\vista_pagina::show($pagina)); ?> visitas
</h3>
<?php /**PATH D:\Tecnologia Web\proyecto2 web\ProyGupadis-3D\proygupadis-3d\resources\views/layauts/vistas.blade.php ENDPATH**/ ?>