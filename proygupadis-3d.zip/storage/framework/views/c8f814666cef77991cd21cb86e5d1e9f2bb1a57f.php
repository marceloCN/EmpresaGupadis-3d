

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('estilo'); ?>
    <style>
        body {
            background: powderblue;

        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-8 mx-auto">
        <img src="main.jpeg" class="img-responsive" alt="imagen" width="920">
        <div class="h-30"></div>
    </div>

    <?php echo $__env->make('layauts.vistas',['pagina'=>'inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layauts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tecnologia Web\proyecto2 web\ProyGupadis-3D\proygupadis-3d\resources\views/home.blade.php ENDPATH**/ ?>