<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/lux/bootstrap.min.css" title="main">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    
    <?php echo $__env->yieldContent('estilo'); ?>
</head>

<body>
    
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="nav-link active text-danger" aria-current="page" href="/">Constructora Gupadis-3D</a>
            <?php if(Request::path() == '/'): ?>
                <a class="nav-link active bg-info text-black" aria-current="page" href="/">Home</a>
            <?php else: ?>
                <a class="nav-link active" aria-current="page" href="/">Home</a>
            <?php endif; ?>

            <?php if(Request::path() == 'nosotros'): ?>
                <a class="nav-link active bg-info text-black" aria-current="page"
                    href="<?php echo e(route('nosotros')); ?>">Nosotros</a>
            <?php else: ?>
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('nosotros')); ?>">Nosotros</a>
            <?php endif; ?>

            <?php if(Request::path() == 'hormigon-premesclado'): ?>
                <a class="nav-link active bg-info text-black" aria-current="page"
                    href="<?php echo e(route('hormigon')); ?>">Hormigon Premesclado</a>
            <?php else: ?>
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('hormigon')); ?>">Hormigon Premesclado</a>
            <?php endif; ?>

            <?php if(Request::path() == 'principales-proyectos'): ?>
                <a class="nav-link active bg-info text-black" aria-current="page"
                    href="<?php echo e(route('proyectos')); ?>">Principales Obras</a>
            <?php else: ?>
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('proyectos')); ?>">Principales Obras</a>
            <?php endif; ?>

            <?php if(Request::path() == 'contacto'): ?>
                <a class="nav-link active bg-info text-black" aria-current="page"
                    href="<?php echo e(route('contacto')); ?>">Contacto</a>
            <?php else: ?>
                <a class="nav-link active" aria-current="page" href="<?php echo e(route('contacto')); ?>">Contacto</a>
            <?php endif; ?>

            <a class="nav-link active" aria-current="page" href="<?php echo e(route('usuario.ingresar')); ?>">Ingresar</a>

            <div class="btn-group">
                <button type="button" class="btn btn-secondary">Temas</button>
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="visually-hidden"></span>
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuReference1">
                    <li><a class="dropdown-item change-style-menu-item" href="#" rel="lux">Adultos</a></li>
                    <li><a class="dropdown-item change-style-menu-item" href="#" rel="simplex">Jovenes</a>
                    </li>
                    <li><a class="dropdown-item change-style-menu-item" href="#" rel="sketchy">Niño</a></li>
            </div>
        </div>
    </nav>
    

    <?php echo $__env->yieldContent('content'); ?>
    

    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        function supports_html5_storage() {
            try {
                return 'localStorage' in window && window['localStorage'] !== null;
            } catch (e) {
                return false;
            }
        }

        var supports_storage = supports_html5_storage();

        function set_theme(theme) {
            $('link[title="main"]').attr('href', theme);
            if (supports_storage) {
                localStorage.theme = theme;
            }
        }
        jQuery(function($) {
            $('body').on('click', '.change-style-menu-item', function() {
                var theme_name = $(this).attr('rel');
                var theme = "//cdn.jsdelivr.net/npm/bootswatch@4.5.2/dist/" + theme_name +
                    "/bootstrap.min.css";
                set_theme(theme);
            });
        });

        if (supports_storage) {
            var theme = localStorage.theme;
            if (theme) {
                set_theme(theme);
            }
        } else {
            /* Don't annoy user with options that don't persist */
            $('#theme-dropdown').hide();
        }
    </script>
</body>

</html>
<?php /**PATH D:\Tecnologia Web\proyecto2 web\ProyGupadis-3D\proygupadis-3d\resources\views/layauts/plantilla.blade.php ENDPATH**/ ?>